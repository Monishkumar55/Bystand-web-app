import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.3';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { busId, routeId, currentStopId, targetStopId } = await req.json();

    if (!busId || !routeId || !targetStopId) {
      return new Response(
        JSON.stringify({ error: 'Missing required parameters' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Fetch historical GPS data for this route
    const { data: gpsHistory, error: gpsError } = await supabase
      .from('gps_history')
      .select('*')
      .eq('route_id', routeId)
      .order('recorded_at', { ascending: false })
      .limit(500);

    if (gpsError) throw gpsError;

    // Fetch route stops
    const { data: routeStops, error: stopsError } = await supabase
      .from('route_stops')
      .select('*, bus_stops(*)')
      .eq('route_id', routeId)
      .order('stop_order', { ascending: true });

    if (stopsError) throw stopsError;

    // Get current bus location
    const { data: busData, error: busError } = await supabase
      .from('buses')
      .select('current_latitude, current_longitude, current_stop_id')
      .eq('id', busId)
      .single();

    if (busError) throw busError;

    // Use Lovable AI to predict ETA based on historical data
    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY is not configured');
    }

    const aiPrompt = `
You are an expert in transportation and ETA prediction. Analyze the following data and predict the estimated time of arrival (ETA) in minutes.

Current Bus Location: Latitude ${busData.current_latitude}, Longitude ${busData.current_longitude}
Current Stop ID: ${busData.current_stop_id || 'Unknown'}
Target Stop ID: ${targetStopId}

Route Stops (in order):
${routeStops.map((stop, idx) => `${idx + 1}. ${stop.bus_stops.stop_name} (${stop.bus_stops.latitude}, ${stop.bus_stops.longitude})`).join('\n')}

Recent GPS History (last 500 points):
${gpsHistory.slice(0, 10).map(h => `Time: ${h.recorded_at}, Lat: ${h.latitude}, Lng: ${h.longitude}, Speed: ${h.speed || 'N/A'} m/s`).join('\n')}
... and ${gpsHistory.length - 10} more historical points

Based on:
1. Distance between current location and target stop
2. Historical speed patterns on this route
3. Number of stops between current and target
4. Time of day patterns (if visible in data)
5. Traffic patterns (inferred from speed variations)

Provide your prediction as a JSON response with:
- eta_minutes: number (estimated minutes to arrival)
- confidence: "high" | "medium" | "low"
- reasoning: brief explanation

Respond ONLY with valid JSON, no other text.
`;

    const aiResponse = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          {
            role: 'system',
            content: 'You are an expert ETA prediction system. Always respond with valid JSON only.'
          },
          {
            role: 'user',
            content: aiPrompt
          }
        ],
        temperature: 0.3,
      }),
    });

    if (!aiResponse.ok) {
      if (aiResponse.status === 429) {
        return new Response(
          JSON.stringify({ error: 'Rate limit exceeded. Please try again later.' }),
          { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      if (aiResponse.status === 402) {
        return new Response(
          JSON.stringify({ error: 'AI credits depleted. Please add credits to continue.' }),
          { status: 402, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      throw new Error(`AI Gateway error: ${aiResponse.status}`);
    }

    const aiData = await aiResponse.json();
    const aiContent = aiData.choices[0].message.content;
    
    // Parse AI response
    let prediction;
    try {
      prediction = JSON.parse(aiContent);
    } catch (e) {
      // If AI didn't return pure JSON, try to extract it
      const jsonMatch = aiContent.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        prediction = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error('Failed to parse AI response');
      }
    }

    return new Response(
      JSON.stringify({
        eta_minutes: prediction.eta_minutes,
        confidence: prediction.confidence,
        reasoning: prediction.reasoning,
        timestamp: new Date().toISOString(),
      }),
      { 
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );

  } catch (error) {
    console.error('Error predicting ETA:', error);
    return new Response(
      JSON.stringify({ 
        error: error instanceof Error ? error.message : 'Unknown error',
        fallback_eta: 15 // Fallback ETA in case of errors
      }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});
