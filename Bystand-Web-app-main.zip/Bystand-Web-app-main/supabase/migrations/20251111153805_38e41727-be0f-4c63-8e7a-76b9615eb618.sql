-- Set replica identity to FULL to get complete row data during updates
ALTER TABLE public.buses REPLICA IDENTITY FULL;