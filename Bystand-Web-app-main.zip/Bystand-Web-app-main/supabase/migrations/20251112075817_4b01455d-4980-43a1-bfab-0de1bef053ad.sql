-- Create drivers table
CREATE TABLE public.drivers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  license_number TEXT NOT NULL UNIQUE,
  phone_number TEXT NOT NULL,
  full_name TEXT NOT NULL,
  status TEXT DEFAULT 'offline' CHECK (status IN ('online', 'offline', 'on_break')),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Create driver_sessions table for check in/out tracking
CREATE TABLE public.driver_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  driver_id UUID REFERENCES public.drivers(id) ON DELETE CASCADE,
  bus_id UUID REFERENCES public.buses(id) ON DELETE SET NULL,
  checked_in_at TIMESTAMPTZ DEFAULT now(),
  checked_out_at TIMESTAMPTZ,
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'completed', 'interrupted')),
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create gps_history table for storing historical GPS data
CREATE TABLE public.gps_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bus_id UUID REFERENCES public.buses(id) ON DELETE CASCADE,
  route_id UUID REFERENCES public.bus_routes(id) ON DELETE CASCADE,
  latitude NUMERIC NOT NULL,
  longitude NUMERIC NOT NULL,
  speed NUMERIC,
  heading NUMERIC,
  accuracy NUMERIC,
  recorded_at TIMESTAMPTZ DEFAULT now(),
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create indexes for performance
CREATE INDEX idx_gps_history_bus_id ON public.gps_history(bus_id);
CREATE INDEX idx_gps_history_route_id ON public.gps_history(route_id);
CREATE INDEX idx_gps_history_recorded_at ON public.gps_history(recorded_at);
CREATE INDEX idx_driver_sessions_driver_id ON public.driver_sessions(driver_id);
CREATE INDEX idx_driver_sessions_bus_id ON public.driver_sessions(bus_id);

-- Enable RLS
ALTER TABLE public.drivers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.driver_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.gps_history ENABLE ROW LEVEL SECURITY;

-- RLS Policies for drivers
CREATE POLICY "Drivers can view their own profile"
  ON public.drivers FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Drivers can update their own profile"
  ON public.drivers FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage all drivers"
  ON public.drivers FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role));

-- RLS Policies for driver_sessions
CREATE POLICY "Drivers can view their own sessions"
  ON public.driver_sessions FOR SELECT
  USING (driver_id IN (SELECT id FROM public.drivers WHERE user_id = auth.uid()));

CREATE POLICY "Drivers can insert their own sessions"
  ON public.driver_sessions FOR INSERT
  WITH CHECK (driver_id IN (SELECT id FROM public.drivers WHERE user_id = auth.uid()));

CREATE POLICY "Drivers can update their own sessions"
  ON public.driver_sessions FOR UPDATE
  USING (driver_id IN (SELECT id FROM public.drivers WHERE user_id = auth.uid()));

CREATE POLICY "Admins can manage all sessions"
  ON public.driver_sessions FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role));

-- RLS Policies for gps_history
CREATE POLICY "Anyone can view GPS history"
  ON public.gps_history FOR SELECT
  USING (true);

CREATE POLICY "Drivers can insert GPS data for their bus"
  ON public.gps_history FOR INSERT
  WITH CHECK (
    bus_id IN (
      SELECT bus_id FROM public.driver_sessions
      WHERE driver_id IN (SELECT id FROM public.drivers WHERE user_id = auth.uid())
      AND status = 'active'
      AND checked_out_at IS NULL
    )
  );

CREATE POLICY "Admins can manage all GPS history"
  ON public.gps_history FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role));

-- Update trigger for drivers
CREATE TRIGGER update_drivers_updated_at
  BEFORE UPDATE ON public.drivers
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Add current_driver_id to buses table
ALTER TABLE public.buses ADD COLUMN current_driver_id UUID REFERENCES public.drivers(id) ON DELETE SET NULL;