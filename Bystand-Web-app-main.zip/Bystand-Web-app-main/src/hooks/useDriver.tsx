import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';

export const useDriver = () => {
  const { user } = useAuth();
  const [isDriver, setIsDriver] = useState(false);
  const [driverId, setDriverId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      setIsDriver(false);
      setDriverId(null);
      setLoading(false);
      return;
    }

    checkDriverStatus();
  }, [user]);

  const checkDriverStatus = async () => {
    try {
      const { data, error } = await supabase
        .from('drivers')
        .select('id')
        .eq('user_id', user?.id)
        .maybeSingle();

      if (error) {
        console.error('Error checking driver status:', error);
        setIsDriver(false);
        setDriverId(null);
      } else {
        setIsDriver(!!data);
        setDriverId(data?.id || null);
      }
    } catch (error) {
      console.error('Error checking driver status:', error);
      setIsDriver(false);
      setDriverId(null);
    } finally {
      setLoading(false);
    }
  };

  return { isDriver, driverId, loading };
};
