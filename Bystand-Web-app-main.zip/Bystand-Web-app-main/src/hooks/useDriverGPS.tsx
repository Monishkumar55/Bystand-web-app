import { useEffect, useRef, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface UseDriverGPSProps {
  busId: string | null;
  routeId: string | null;
  isActive: boolean;
}

export const useDriverGPS = ({ busId, routeId, isActive }: UseDriverGPSProps) => {
  const [tracking, setTracking] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const watchIdRef = useRef<number | null>(null);
  const updateIntervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (isActive && busId && routeId) {
      startTracking();
    } else {
      stopTracking();
    }

    return () => {
      stopTracking();
    };
  }, [isActive, busId, routeId]);

  const startTracking = async () => {
    if (!navigator.geolocation) {
      toast.error('Geolocation is not supported by your browser');
      return;
    }

    setTracking(true);
    toast.success('GPS tracking started');

    // Watch position with high accuracy
    watchIdRef.current = navigator.geolocation.watchPosition(
      async (position) => {
        const { latitude, longitude, speed, heading, accuracy } = position.coords;

        // Update bus location in real-time
        const { error: busError } = await supabase
          .from('buses')
          .update({
            current_latitude: latitude,
            current_longitude: longitude,
            last_updated: new Date().toISOString(),
          })
          .eq('id', busId);

        if (busError) {
          console.error('Error updating bus location:', busError);
          return;
        }

        // Store GPS history for ML predictions
        const { error: historyError } = await supabase
          .from('gps_history')
          .insert({
            bus_id: busId,
            route_id: routeId,
            latitude,
            longitude,
            speed: speed || null,
            heading: heading || null,
            accuracy: accuracy || null,
            recorded_at: new Date().toISOString(),
          });

        if (historyError) {
          console.error('Error storing GPS history:', historyError);
        }

        setLastUpdate(new Date());
      },
      (error) => {
        console.error('GPS error:', error);
        toast.error('GPS tracking error: ' + error.message);
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0,
      }
    );
  };

  const stopTracking = () => {
    if (watchIdRef.current !== null) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }
    if (updateIntervalRef.current) {
      clearInterval(updateIntervalRef.current);
      updateIntervalRef.current = null;
    }
    setTracking(false);
    setLastUpdate(null);
  };

  return { tracking, lastUpdate };
};
