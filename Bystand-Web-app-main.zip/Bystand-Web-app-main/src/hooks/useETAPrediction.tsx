import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface ETAPredictionParams {
  busId: string | null;
  routeId: string | null;
  currentStopId?: string | null;
  targetStopId: string;
}

interface ETAResult {
  eta_minutes: number;
  confidence: 'high' | 'medium' | 'low';
  reasoning: string;
  timestamp: string;
}

export const useETAPrediction = ({ busId, routeId, currentStopId, targetStopId }: ETAPredictionParams) => {
  const [eta, setEta] = useState<ETAResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (busId && routeId && targetStopId) {
      fetchETA();
    }
  }, [busId, routeId, currentStopId, targetStopId]);

  const fetchETA = async () => {
    setLoading(true);
    setError(null);

    try {
      const { data, error } = await supabase.functions.invoke('predict-eta', {
        body: {
          busId,
          routeId,
          currentStopId,
          targetStopId,
        },
      });

      if (error) throw error;

      setEta(data);
    } catch (err) {
      console.error('Error fetching ETA:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch ETA');
      // Use fallback ETA
      setEta({
        eta_minutes: 15,
        confidence: 'low',
        reasoning: 'Using fallback estimate',
        timestamp: new Date().toISOString(),
      });
    } finally {
      setLoading(false);
    }
  };

  const refreshETA = () => {
    if (busId && routeId && targetStopId) {
      fetchETA();
    }
  };

  return { eta, loading, error, refreshETA };
};
