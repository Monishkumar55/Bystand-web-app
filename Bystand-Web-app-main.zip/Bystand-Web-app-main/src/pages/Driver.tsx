import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useDriver } from '@/hooks/useDriver';
import { useDriverGPS } from '@/hooks/useDriverGPS';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { LogIn, LogOut, Navigation, Clock, Bus, MapPin } from 'lucide-react';
import LiveIndicator from '@/components/LiveIndicator';

const Driver = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { isDriver, driverId, loading: driverLoading } = useDriver();
  const [driverData, setDriverData] = useState<any>(null);
  const [currentSession, setCurrentSession] = useState<any>(null);
  const [selectedBus, setSelectedBus] = useState<string>('');
  const [buses, setBuses] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const { tracking, lastUpdate } = useDriverGPS({
    busId: currentSession?.bus_id || null,
    routeId: currentSession?.bus?.route_id || null,
    isActive: currentSession?.status === 'active',
  });

  useEffect(() => {
    if (!user) {
      navigate('/');
      return;
    }

    if (!driverLoading && !isDriver) {
      toast.error('Access denied. Driver account required.');
      navigate('/');
      return;
    }

    if (driverId) {
      fetchDriverData();
      fetchBuses();
    }
  }, [user, isDriver, driverId, driverLoading]);

  const fetchDriverData = async () => {
    try {
      const { data: driver, error } = await supabase
        .from('drivers')
        .select('*')
        .eq('id', driverId)
        .single();

      if (error) throw error;
      setDriverData(driver);

      // Check for active session
      const { data: session, error: sessionError } = await supabase
        .from('driver_sessions')
        .select('*, buses(id, bus_number, route_id, bus_routes(route_name, route_number))')
        .eq('driver_id', driverId)
        .eq('status', 'active')
        .is('checked_out_at', null)
        .maybeSingle();

      if (sessionError && sessionError.code !== 'PGRST116') throw sessionError;
      setCurrentSession(session);
    } catch (error) {
      console.error('Error fetching driver data:', error);
      toast.error('Failed to load driver data');
    } finally {
      setLoading(false);
    }
  };

  const fetchBuses = async () => {
    try {
      const { data, error } = await supabase
        .from('buses')
        .select('*, bus_routes(route_name, route_number)')
        .eq('status', 'active')
        .is('current_driver_id', null);

      if (error) throw error;
      setBuses(data || []);
    } catch (error) {
      console.error('Error fetching buses:', error);
    }
  };

  const handleCheckIn = async () => {
    if (!selectedBus) {
      toast.error('Please select a bus');
      return;
    }

    try {
      // Create new session
      const { data: session, error: sessionError } = await supabase
        .from('driver_sessions')
        .insert({
          driver_id: driverId,
          bus_id: selectedBus,
          status: 'active',
        })
        .select('*, buses(id, bus_number, route_id, bus_routes(route_name, route_number))')
        .single();

      if (sessionError) throw sessionError;

      // Update bus with current driver
      const { error: busError } = await supabase
        .from('buses')
        .update({ current_driver_id: driverId, status: 'active' })
        .eq('id', selectedBus);

      if (busError) throw busError;

      // Update driver status
      const { error: driverError } = await supabase
        .from('drivers')
        .update({ status: 'online' })
        .eq('id', driverId);

      if (driverError) throw driverError;

      setCurrentSession(session);
      toast.success('Checked in successfully');
      fetchBuses();
    } catch (error) {
      console.error('Error checking in:', error);
      toast.error('Failed to check in');
    }
  };

  const handleCheckOut = async () => {
    if (!currentSession) return;

    try {
      // Update session
      const { error: sessionError } = await supabase
        .from('driver_sessions')
        .update({
          checked_out_at: new Date().toISOString(),
          status: 'completed',
        })
        .eq('id', currentSession.id);

      if (sessionError) throw sessionError;

      // Update bus
      const { error: busError } = await supabase
        .from('buses')
        .update({ current_driver_id: null })
        .eq('id', currentSession.bus_id);

      if (busError) throw busError;

      // Update driver status
      const { error: driverError } = await supabase
        .from('drivers')
        .update({ status: 'offline' })
        .eq('id', driverId);

      if (driverError) throw driverError;

      setCurrentSession(null);
      toast.success('Checked out successfully');
      fetchBuses();
    } catch (error) {
      console.error('Error checking out:', error);
      toast.error('Failed to check out');
    }
  };

  const updateDriverStatus = async (status: string) => {
    try {
      const { error } = await supabase
        .from('drivers')
        .update({ status })
        .eq('id', driverId);

      if (error) throw error;
      setDriverData({ ...driverData, status });
      toast.success(`Status updated to ${status}`);
    } catch (error) {
      console.error('Error updating status:', error);
      toast.error('Failed to update status');
    }
  };

  if (loading || driverLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 max-w-4xl pb-24">
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-2">Driver Mode</h1>
        <p className="text-muted-foreground">Manage your shift and track your route</p>
      </div>

      {/* Driver Info Card */}
      <Card className="mb-6">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>{driverData?.full_name}</CardTitle>
              <CardDescription>License: {driverData?.license_number}</CardDescription>
            </div>
            <Badge variant={driverData?.status === 'online' ? 'default' : 'secondary'}>
              {driverData?.status}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          {currentSession && (
            <div className="space-y-2 mb-4">
              <div className="flex items-center gap-2">
                <Bus className="w-4 h-4 text-muted-foreground" />
                <span className="font-medium">Bus {currentSession.buses?.bus_number}</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm text-muted-foreground">
                  {currentSession.buses?.bus_routes?.route_name}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm text-muted-foreground">
                  Started: {new Date(currentSession.checked_in_at).toLocaleTimeString()}
                </span>
              </div>
            </div>
          )}

          <div className="flex gap-2">
            <Select
              value={driverData?.status}
              onValueChange={updateDriverStatus}
              disabled={!currentSession}
            >
              <SelectTrigger className="flex-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="online">Online</SelectItem>
                <SelectItem value="on_break">On Break</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* GPS Tracking Status */}
      {currentSession && (
        <Card className="mb-6">
          <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Navigation className="w-5 h-5" />
                GPS Tracking
              </CardTitle>
              <CardDescription>Real-time location updates</CardDescription>
            </div>
            <LiveIndicator lastUpdated={lastUpdate?.toISOString()} />
          </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Status</span>
                <Badge variant={tracking ? 'default' : 'secondary'}>
                  {tracking ? 'Active' : 'Inactive'}
                </Badge>
              </div>
              {lastUpdate && (
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Last Update</span>
                  <span className="text-sm">{lastUpdate.toLocaleTimeString()}</span>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Check In/Out Section */}
      <Card>
        <CardHeader>
          <CardTitle>Shift Management</CardTitle>
          <CardDescription>
            {currentSession ? 'End your current shift' : 'Start a new shift'}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {!currentSession ? (
            <>
              <Select value={selectedBus} onValueChange={setSelectedBus}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a bus" />
                </SelectTrigger>
                <SelectContent>
                  {buses.map((bus) => (
                    <SelectItem key={bus.id} value={bus.id}>
                      Bus {bus.bus_number} - {bus.bus_routes?.route_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button
                onClick={handleCheckIn}
                className="w-full"
                disabled={!selectedBus}
              >
                <LogIn className="w-4 h-4 mr-2" />
                Check In
              </Button>
            </>
          ) : (
            <Button
              onClick={handleCheckOut}
              variant="destructive"
              className="w-full"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Check Out
            </Button>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default Driver;
