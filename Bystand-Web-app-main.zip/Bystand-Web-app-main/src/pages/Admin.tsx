import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Bus, MapPin, Route, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import BottomNav from "@/components/BottomNav";
import BusSimulator from "@/components/BusSimulator";
import { useAuth } from "@/contexts/AuthContext";
import { useAdmin } from "@/hooks/useAdmin";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

const Admin = () => {
  const [activeTab, setActiveTab] = useState("admin");
  const navigate = useNavigate();
  const { user } = useAuth();
  const { isAdmin, loading } = useAdmin();
  const [routes, setRoutes] = useState<any[]>([]);
  const [buses, setBuses] = useState<any[]>([]);
  const [stops, setStops] = useState<any[]>([]);

  useEffect(() => {
    if (!user) {
      navigate("/");
      return;
    }

    if (!loading && !isAdmin) {
      toast.error("Access denied. Admin privileges required.");
      navigate("/home");
      return;
    }

    if (isAdmin) {
      fetchData();
    }
  }, [user, isAdmin, loading, navigate]);

  const fetchData = async () => {
    try {
      const [routesRes, busesRes, stopsRes] = await Promise.all([
        supabase.from('bus_routes').select('*').order('route_number'),
        supabase.from('buses').select('*, route:bus_routes(*)').order('bus_number'),
        supabase.from('bus_stops').select('*').order('stop_name'),
      ]);

      if (routesRes.error) throw routesRes.error;
      if (busesRes.error) throw busesRes.error;
      if (stopsRes.error) throw stopsRes.error;

      setRoutes(routesRes.data || []);
      setBuses(busesRes.data || []);
      setStops(stopsRes.data || []);
    } catch (error) {
      console.error('Error fetching admin data:', error);
      toast.error('Failed to load admin data');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <div className="text-center">
          <Shield className="w-12 h-12 mx-auto mb-4 text-primary animate-pulse" />
          <p className="text-muted-foreground">Verifying admin access...</p>
        </div>
      </div>
    );
  }

  if (!isAdmin) {
    return null;
  }

  return (
    <div className="flex flex-col min-h-screen bg-background pb-20">
      {/* Header */}
      <header className="bg-gradient-primary text-white px-4 pt-6 pb-8 rounded-b-3xl shadow-float">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center gap-3 mb-2">
            <Shield className="w-8 h-8" />
            <h1 className="text-2xl font-bold">Admin Dashboard</h1>
          </div>
          <p className="text-sm text-white/80">Manage routes, buses, and stops</p>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 px-4 py-6">
        <div className="max-w-7xl mx-auto">
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid w-full grid-cols-4 mb-6">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="routes">Routes</TabsTrigger>
              <TabsTrigger value="buses">Buses</TabsTrigger>
              <TabsTrigger value="stops">Stops</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card className="p-6 shadow-card rounded-2xl bg-gradient-card">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Total Routes</p>
                      <h3 className="text-3xl font-bold text-foreground">{routes.length}</h3>
                    </div>
                    <Route className="w-10 h-10 text-primary" />
                  </div>
                </Card>

                <Card className="p-6 shadow-card rounded-2xl bg-gradient-card">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Active Buses</p>
                      <h3 className="text-3xl font-bold text-foreground">{buses.length}</h3>
                    </div>
                    <Bus className="w-10 h-10 text-chalo-yellow" />
                  </div>
                </Card>

                <Card className="p-6 shadow-card rounded-2xl bg-gradient-card">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Bus Stops</p>
                      <h3 className="text-3xl font-bold text-foreground">{stops.length}</h3>
                    </div>
                    <MapPin className="w-10 h-10 text-chalo-orange" />
                  </div>
                </Card>
              </div>

              {/* GPS Simulator */}
              <BusSimulator buses={buses} />

              <Card className="p-6 shadow-card rounded-2xl bg-muted/30">
                <h3 className="text-lg font-semibold text-foreground mb-4">📡 Real-Time GPS Tracking</h3>
                <div className="space-y-3 text-sm text-muted-foreground">
                  <p>
                    The GPS simulator above allows you to test real-time bus location updates.
                    When active, it simulates GPS movements for selected buses every 3 seconds.
                  </p>
                  <div className="space-y-2">
                    <p className="font-medium text-foreground">How it works:</p>
                    <ul className="list-disc list-inside space-y-1 ml-2">
                      <li>Simulates movements of ~100-500 meters per update</li>
                      <li>Updates bus positions in the database automatically</li>
                      <li>Live updates appear instantly on the map for all users</li>
                      <li>Randomly adjusts passenger occupancy (+/- 2 passengers)</li>
                      <li>Uses Supabase Realtime for instant synchronization</li>
                    </ul>
                  </div>
                  <p className="text-xs bg-primary/10 p-3 rounded-lg border border-primary/20">
                    <strong>💡 Tip:</strong> Open the home page in another tab to see the real-time 
                    updates happening live as the simulator runs!
                  </p>
                </div>
              </Card>

              <Card className="p-6 shadow-card rounded-2xl">
                <h3 className="text-lg font-semibold text-foreground mb-4">Quick Actions</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <Button className="w-full justify-start bg-primary hover:bg-primary/90 text-white rounded-xl">
                    <Route className="w-5 h-5 mr-2" />
                    Add New Route
                  </Button>
                  <Button className="w-full justify-start bg-chalo-yellow hover:bg-chalo-yellow/90 text-white rounded-xl">
                    <Bus className="w-5 h-5 mr-2" />
                    Add New Bus
                  </Button>
                  <Button className="w-full justify-start bg-chalo-orange hover:bg-chalo-orange/90 text-white rounded-xl">
                    <MapPin className="w-5 h-5 mr-2" />
                    Add New Stop
                  </Button>
                  <Button className="w-full justify-start bg-chalo-green hover:bg-chalo-green/90 text-white rounded-xl">
                    <Shield className="w-5 h-5 mr-2" />
                    Manage Admins
                  </Button>
                </div>
              </Card>
            </TabsContent>

            <TabsContent value="routes" className="space-y-4">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold text-foreground">Bus Routes</h3>
                <Button className="bg-primary hover:bg-primary/90 text-white rounded-xl">
                  Add Route
                </Button>
              </div>
              <div className="space-y-3">
                {routes.map((route) => (
                  <Card key={route.id} className="p-4 shadow-card rounded-2xl">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="bg-primary text-white w-12 h-12 rounded-xl flex items-center justify-center font-bold">
                          {route.route_number}
                        </div>
                        <div>
                          <h4 className="font-semibold text-foreground">{route.route_name}</h4>
                          <p className="text-sm text-muted-foreground">
                            {route.start_point} → {route.end_point}
                          </p>
                          <p className="text-sm text-muted-foreground">Fare: ₹{route.fare}</p>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" className="rounded-xl">
                          Edit
                        </Button>
                        <Button variant="destructive" size="sm" className="rounded-xl">
                          Delete
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="buses" className="space-y-4">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold text-foreground">Buses</h3>
                <Button className="bg-primary hover:bg-primary/90 text-white rounded-xl">
                  Add Bus
                </Button>
              </div>
              <div className="space-y-3">
                {buses.map((bus) => (
                  <Card key={bus.id} className="p-4 shadow-card rounded-2xl">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="bg-chalo-yellow text-white w-12 h-12 rounded-xl flex items-center justify-center font-bold">
                          {bus.bus_number}
                        </div>
                        <div>
                          <h4 className="font-semibold text-foreground">
                            {bus.route?.route_name || 'No Route Assigned'}
                          </h4>
                          <p className="text-sm text-muted-foreground">
                            Status: {bus.status} | Capacity: {bus.current_occupancy}/{bus.capacity}
                          </p>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" className="rounded-xl">
                          Edit
                        </Button>
                        <Button variant="destructive" size="sm" className="rounded-xl">
                          Delete
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="stops" className="space-y-4">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold text-foreground">Bus Stops</h3>
                <Button className="bg-primary hover:bg-primary/90 text-white rounded-xl">
                  Add Stop
                </Button>
              </div>
              <div className="space-y-3">
                {stops.map((stop) => (
                  <Card key={stop.id} className="p-4 shadow-card rounded-2xl">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="bg-chalo-orange text-white w-12 h-12 rounded-xl flex items-center justify-center">
                          <MapPin className="w-6 h-6" />
                        </div>
                        <div>
                          <h4 className="font-semibold text-foreground">{stop.stop_name}</h4>
                          <p className="text-sm text-muted-foreground">
                            Lat: {stop.latitude}, Lng: {stop.longitude}
                          </p>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" className="rounded-xl">
                          Edit
                        </Button>
                        <Button variant="destructive" size="sm" className="rounded-xl">
                          Delete
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  );
};

export default Admin;
