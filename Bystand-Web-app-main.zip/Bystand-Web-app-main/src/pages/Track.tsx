import { useParams, useNavigate } from "react-router-dom";
import { ArrowLeft, Bus, MapPin, Clock, Users, Bell, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import MapComponent from "@/components/MapComponent";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useETAPrediction } from "@/hooks/useETAPrediction";
import { toast } from "sonner";

const Track = () => {
  const { routeId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [busData, setBusData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [nextStopId, setNextStopId] = useState<string | null>(null);

  const { eta, loading: etaLoading, refreshETA } = useETAPrediction({
    busId: busData?.bus?.id || null,
    routeId: busData?.routeId || null,
    currentStopId: busData?.bus?.current_stop_id || null,
    targetStopId: nextStopId || '',
  });

  useEffect(() => {
    if (!user) {
      navigate("/");
      return;
    }
    fetchBusData();
  }, [routeId, user, navigate]);

  const fetchBusData = async () => {
    try {
      const { data: route, error: routeError } = await supabase
        .from('bus_routes')
        .select('*')
        .eq('route_number', routeId)
        .single();

      if (routeError) throw routeError;

      const { data: buses, error: busError } = await supabase
        .from('buses')
        .select('*')
        .eq('route_id', route.id)
        .eq('status', 'active')
        .limit(1)
        .maybeSingle();

      if (busError && busError.code !== 'PGRST116') throw busError;

      const { data: stops, error: stopsError } = await supabase
        .from('route_stops')
        .select(`
          *,
          stop:bus_stops(*)
        `)
        .eq('route_id', route.id)
        .order('stop_order', { ascending: true });

      if (stopsError) throw stopsError;

      // Determine next stop
      const firstStopId = stops?.[0]?.stop_id || null;
      setNextStopId(firstStopId);

      setBusData({
        route: route.route_number,
        name: route.route_name,
        routeId: route.id,
        bus: buses,
        stops: stops?.map(s => ({
          id: s.stop_id,
          name: s.stop.stop_name,
          time: `${s.estimated_time_minutes} min`,
          passed: false
        })) || [],
        capacity: buses ? `${Math.round((buses.current_occupancy / buses.capacity) * 100)}%` : "N/A",
        status: "On Time",
      });
    } catch (error) {
      console.error('Error fetching bus data:', error);
      // Fallback to mock data
      setBusData({
        route: routeId || "101",
        name: "Bus Route",
        currentLocation: "Unknown",
        nextStop: "Loading...",
        estimatedArrival: "N/A",
        stops: [],
        capacity: "N/A",
        status: "Unknown",
      });
    } finally {
      setLoading(false);
    }
  };

  if (loading || !busData) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col bg-background">
      {/* Header */}
      <div className="bg-gradient-primary text-white p-4 rounded-b-3xl shadow-float">
        <div className="flex items-center gap-3 mb-4">
          <Button
            size="icon"
            variant="ghost"
            onClick={() => navigate(-1)}
            className="text-white hover:bg-white/20 rounded-full"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <span className="text-2xl font-bold">Route {busData.route}</span>
              <Badge className="bg-chalo-green text-white">{busData.status}</Badge>
            </div>
            <p className="text-sm text-white/80">{busData.name}</p>
          </div>
        </div>

        {/* Live Location Card */}
        <Card className="bg-white/10 backdrop-blur-sm border-white/20 p-4 rounded-2xl space-y-3">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center flex-shrink-0">
              <Bus className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm text-white/80">Currently at</p>
              <p className="font-semibold text-white truncate">{busData.currentLocation}</p>
            </div>
          </div>

          <div className="flex items-center gap-4 pt-3 border-t border-white/20">
            <div className="flex items-center gap-2 text-sm">
              <Clock className="w-4 h-4 text-white/80" />
              <span className="text-white">Next: {busData.stops[0]?.name || 'Unknown'}</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              {etaLoading ? (
                <span className="text-white/80">Calculating...</span>
              ) : eta ? (
                <>
                  <span className="font-bold text-white">{eta.eta_minutes} min</span>
                  <Badge 
                    variant={eta.confidence === 'high' ? 'default' : 'secondary'}
                    className="text-xs"
                  >
                    {eta.confidence}
                  </Badge>
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => {
                      refreshETA();
                      toast.success('Refreshing ETA...');
                    }}
                    className="h-6 w-6 text-white hover:bg-white/20"
                  >
                    <RefreshCw className="w-3 h-3" />
                  </Button>
                </>
              ) : (
                <span className="text-white/80">N/A</span>
              )}
            </div>
          </div>
        </Card>
      </div>

      {/* Real Map */}
      <div className="relative h-64 mx-4 mt-4 rounded-2xl overflow-hidden shadow-card">
        <MapComponent
          buses={busData.bus ? [{
            id: busData.bus.id,
            latitude: busData.bus.current_latitude || 12.9716,
            longitude: busData.bus.current_longitude || 77.5946,
            busNumber: busData.bus.bus_number
          }] : []}
          center={busData.bus && busData.bus.current_latitude && busData.bus.current_longitude
            ? [busData.bus.current_longitude, busData.bus.current_latitude]
            : [77.5946, 12.9716]}
          zoom={14}
          className="w-full h-full"
        />
      </div>

      {/* Actions */}
      <div className="px-4 py-4 space-y-3">
        <Button className="w-full bg-primary hover:bg-primary/90 text-white h-12 rounded-xl shadow-soft">
          <Bell className="w-5 h-5 mr-2" />
          Notify Me at Next Stop
        </Button>

        <div className="flex gap-3">
          <Button variant="outline" className="flex-1 h-12 rounded-xl border-2">
            <Users className="w-5 h-5 mr-2" />
            Capacity: {busData.capacity}
          </Button>
          <Button
            variant="outline"
            className="flex-1 h-12 rounded-xl border-2"
            onClick={() => navigate(`/schedule/${busData.route}`)}
          >
            <Clock className="w-5 h-5 mr-2" />
            Full Schedule
          </Button>
        </div>
      </div>

      {/* Upcoming Stops */}
      <div className="flex-1 overflow-y-auto px-4 pb-4">
        <h3 className="font-bold text-lg mb-3 text-foreground">Upcoming Stops</h3>
        <div className="space-y-2">
          {busData.stops.map((stop, index) => (
            <Card
              key={index}
              className={`p-4 shadow-card rounded-2xl transition-all ${
                index === 0 ? "border-2 border-primary bg-primary/5" : ""
              }`}
            >
              <div className="flex items-center gap-3">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0 ${
                    index === 0 ? "bg-primary text-white" : "bg-muted text-muted-foreground"
                  }`}
                >
                  {index + 1}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-foreground truncate">{stop.name}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Clock className="w-3 h-3 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">{stop.time}</span>
                  </div>
                </div>
                {index === 0 && (
                  <Badge className="bg-primary text-white flex-shrink-0">Next</Badge>
                )}
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Track;
