import { useNavigate } from "react-router-dom";
import { ArrowLeft, User, Phone, Mail, LogOut, Bell, CreditCard, HelpCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/contexts/AuthContext";

const Profile = () => {
  const navigate = useNavigate();
  const { user, signOut } = useAuth();

  const handleSignOut = async () => {
    await signOut();
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-gradient-primary text-white p-4 rounded-b-3xl shadow-float">
        <div className="flex items-center gap-3 mb-4">
          <Button
            size="icon"
            variant="ghost"
            onClick={() => navigate(-1)}
            className="text-white hover:bg-white/20 rounded-full"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-2xl font-bold">Profile</h1>
        </div>

        {/* Profile Info Card */}
        <Card className="bg-white/10 backdrop-blur-sm border-white/20 p-4 rounded-2xl">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
              <User className="w-8 h-8 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-bold text-white text-lg truncate">
                {user?.email?.split('@')[0] || 'User'}
              </p>
              <p className="text-sm text-white/80 truncate">{user?.email}</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Menu Items */}
      <div className="p-4 space-y-3">
        <Card className="p-4 rounded-2xl shadow-card">
          <h3 className="font-semibold text-sm text-muted-foreground mb-3">
            ACCOUNT DETAILS
          </h3>
          
          <div className="space-y-1">
            <button className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-muted/50 transition-colors">
              <Mail className="w-5 h-5 text-muted-foreground" />
              <div className="flex-1 text-left">
                <p className="text-sm font-medium">Email</p>
                <p className="text-xs text-muted-foreground">{user?.email}</p>
              </div>
            </button>

            <button className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-muted/50 transition-colors">
              <Phone className="w-5 h-5 text-muted-foreground" />
              <div className="flex-1 text-left">
                <p className="text-sm font-medium">Phone</p>
                <p className="text-xs text-muted-foreground">
                  {user?.phone || 'Not provided'}
                </p>
              </div>
            </button>
          </div>
        </Card>

        <Card className="p-4 rounded-2xl shadow-card">
          <h3 className="font-semibold text-sm text-muted-foreground mb-3">
            PREFERENCES
          </h3>
          
          <div className="space-y-1">
            <button 
              onClick={() => navigate('/notifications')}
              className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-muted/50 transition-colors"
            >
              <Bell className="w-5 h-5 text-muted-foreground" />
              <span className="text-sm font-medium flex-1 text-left">Notifications</span>
              <span className="text-xs text-primary">View</span>
            </button>

            <button 
              onClick={() => navigate('/tickets')}
              className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-muted/50 transition-colors"
            >
              <CreditCard className="w-5 h-5 text-muted-foreground" />
              <span className="text-sm font-medium flex-1 text-left">My Tickets</span>
              <span className="text-xs text-primary">View</span>
            </button>

            <button className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-muted/50 transition-colors">
              <HelpCircle className="w-5 h-5 text-muted-foreground" />
              <span className="text-sm font-medium flex-1 text-left">Help & Support</span>
            </button>
          </div>
        </Card>

        <Separator />

        <Button
          variant="destructive"
          className="w-full h-14 rounded-xl shadow-soft"
          onClick={handleSignOut}
        >
          <LogOut className="w-5 h-5 mr-2" />
          Sign Out
        </Button>
      </div>
    </div>
  );
};

export default Profile;