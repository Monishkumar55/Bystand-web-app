import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Ticket, QrCode, Clock, MapPin, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

const Tickets = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [tickets, setTickets] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchTickets();
    }
  }, [user]);

  const fetchTickets = async () => {
    try {
      const { data, error } = await supabase
        .from('tickets')
        .select(`
          *,
          route:bus_routes(*),
          from_stop:bus_stops!tickets_from_stop_id_fkey(*),
          to_stop:bus_stops!tickets_to_stop_id_fkey(*)
        `)
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setTickets(data || []);
    } catch (error: any) {
      toast.error('Failed to load tickets');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'valid':
        return 'bg-chalo-green text-white';
      case 'used':
        return 'bg-muted text-muted-foreground';
      case 'expired':
        return 'bg-destructive/10 text-destructive';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-gradient-primary text-white p-4 rounded-b-3xl shadow-float">
        <div className="flex items-center gap-3 mb-2">
          <Button
            size="icon"
            variant="ghost"
            onClick={() => navigate(-1)}
            className="text-white hover:bg-white/20 rounded-full"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold">My Tickets</h1>
            <p className="text-sm text-white/80">View your travel history</p>
          </div>
        </div>
      </div>

      {/* Tickets List */}
      <div className="p-4 space-y-3">
        {tickets.length === 0 ? (
          <Card className="p-8 text-center">
            <Ticket className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold mb-2">No tickets yet</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Book your first ticket to start traveling
            </p>
            <Button onClick={() => navigate('/home')}>
              Browse Routes
            </Button>
          </Card>
        ) : (
          tickets.map((ticket) => (
            <Card key={ticket.id} className="p-4 shadow-card rounded-2xl">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center">
                    <Ticket className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-bold text-foreground">
                      Route {ticket.route?.route_number}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      {ticket.route?.route_name}
                    </p>
                  </div>
                </div>
                <Badge className={getStatusColor(ticket.status)}>
                  {ticket.status === 'valid' && <CheckCircle2 className="w-3 h-3 mr-1" />}
                  {ticket.status.toUpperCase()}
                </Badge>
              </div>

              <div className="space-y-2 mb-3">
                <div className="flex items-center gap-2 text-sm">
                  <MapPin className="w-4 h-4 text-muted-foreground" />
                  <span className="font-medium">From:</span>
                  <span className="text-muted-foreground">{ticket.from_stop?.stop_name}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <MapPin className="w-4 h-4 text-muted-foreground" />
                  <span className="font-medium">To:</span>
                  <span className="text-muted-foreground">{ticket.to_stop?.stop_name}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Clock className="w-4 h-4 text-muted-foreground" />
                  <span className="font-medium">Valid until:</span>
                  <span className="text-muted-foreground">
                    {new Date(ticket.valid_until).toLocaleString()}
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-between pt-3 border-t">
                <div className="flex items-center gap-2">
                  <QrCode className="w-4 h-4 text-muted-foreground" />
                  <span className="text-xs font-mono text-muted-foreground">
                    {ticket.ticket_code}
                  </span>
                </div>
                <span className="text-lg font-bold text-primary">
                  ₹{ticket.fare_paid}
                </span>
              </div>
            </Card>
          ))
        )}
      </div>
    </div>
  );
};

export default Tickets;