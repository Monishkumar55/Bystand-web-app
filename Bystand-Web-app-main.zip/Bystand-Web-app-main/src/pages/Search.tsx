import { useState } from "react";
import { ArrowLeft, Search as SearchIcon, MapPin, Navigation, Bus } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import BottomNav from "@/components/BottomNav";

const Search = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("search");
  const navigate = useNavigate();

  const routes = [
    { number: "101", name: "Downtown Express", stops: "24 stops" },
    { number: "25", name: "Central Station", stops: "18 stops" },
    { number: "47", name: "University Loop", stops: "32 stops" },
    { number: "82", name: "Airport Shuttle", stops: "15 stops" },
    { number: "15", name: "Mall Connect", stops: "20 stops" },
    { number: "63", name: "Hospital Route", stops: "22 stops" },
  ];

  const nearbyStops = [
    { name: "Central Plaza", distance: "50m", routes: ["101", "25", "47"] },
    { name: "City Hall", distance: "120m", routes: ["101", "82"] },
    { name: "University Gate", distance: "200m", routes: ["47", "15"] },
  ];

  const filteredRoutes = routes.filter(
    (route) =>
      route.number.includes(searchQuery) ||
      route.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex flex-col min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-gradient-primary text-white p-4 rounded-b-3xl shadow-float sticky top-0 z-10">
        <div className="flex items-center gap-3 mb-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate(-1)}
            className="text-white hover:bg-white/20 rounded-full"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-xl font-bold">Search Routes & Stops</h1>
        </div>

        {/* Search Input */}
        <div className="relative">
          <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Route number, stop name, or location..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-12 pr-4 h-14 bg-white border-0 shadow-card rounded-2xl text-foreground placeholder:text-muted-foreground"
          />
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 px-4 py-6 space-y-6">
        {/* Nearby Stops */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-bold text-foreground">Nearby Stops</h2>
            <Button
              variant="ghost"
              size="sm"
              className="text-primary text-sm font-medium"
            >
              <Navigation className="w-4 h-4 mr-1" />
              Locate Me
            </Button>
          </div>

          <div className="space-y-2">
            {nearbyStops.map((stop, index) => (
              <Card
                key={index}
                className="p-4 shadow-card rounded-2xl hover:shadow-float transition-all cursor-pointer"
              >
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-foreground">{stop.name}</h3>
                    <p className="text-sm text-muted-foreground mt-1">{stop.distance} away</p>
                    <div className="flex gap-2 mt-2">
                      {stop.routes.map((route) => (
                        <span
                          key={route}
                          className="px-2 py-1 bg-primary/10 text-primary text-xs font-bold rounded-lg"
                        >
                          {route}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>

        {/* All Routes */}
        <div>
          <h2 className="text-lg font-bold text-foreground mb-3">
            {searchQuery ? "Search Results" : "All Routes"}
          </h2>

          <div className="space-y-2">
            {filteredRoutes.map((route) => (
              <Card
                key={route.number}
                className="p-4 shadow-card rounded-2xl hover:shadow-float transition-all cursor-pointer"
                onClick={() => navigate(`/schedule/${route.number}`)}
              >
                <div className="flex items-center gap-3">
                  <div className="bg-primary text-white w-12 h-12 rounded-xl flex items-center justify-center font-bold text-lg">
                    {route.number}
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-foreground">{route.name}</h3>
                    <p className="text-sm text-muted-foreground">{route.stops}</p>
                  </div>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="text-primary"
                    onClick={(e) => {
                      e.stopPropagation();
                      navigate(`/track/${route.number}`);
                    }}
                  >
                    <Bus className="w-4 h-4" />
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </main>

      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  );
};

export default Search;
