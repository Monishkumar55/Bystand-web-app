import { useState, useEffect } from "react";
import { Bus, MapPin, Clock, TrendingUp, User, Navigation } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import BottomNav from "@/components/BottomNav";
import MapComponent from "@/components/MapComponent";
import NotificationBell from "@/components/NotificationBell";
import LiveIndicator from "@/components/LiveIndicator";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useGeolocation } from "@/hooks/useGeolocation";
import { useNotifications } from "@/hooks/useNotifications";
import { toast } from "sonner";

const Home = () => {
  const [activeTab, setActiveTab] = useState("home");
  const [buses, setBuses] = useState<any[]>([]);
  const [nearbyBuses, setNearbyBuses] = useState<any[]>([]);
  const navigate = useNavigate();
  const { user } = useAuth();
  const { latitude, longitude, error: locationError, loading: locationLoading } = useGeolocation();
  const { permission, requestPermission, sendNotification } = useNotifications();
  const [notifiedBuses, setNotifiedBuses] = useState<Set<string>>(new Set());
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());

  useEffect(() => {
    if (!user) {
      navigate("/");
      return;
    }
    fetchBuses();
    subscribeToBuses();
  }, [user, navigate]);

  useEffect(() => {
    if (locationError) {
      toast.error("Please enable location access to find nearby buses", {
        description: "Location access is required for finding nearby buses"
      });
    }
  }, [locationError]);

  // Request notification permission when location is available
  useEffect(() => {
    if (latitude && longitude && permission === 'default') {
      requestPermission();
    }
  }, [latitude, longitude, permission]);

  // Check for nearby buses and send notifications
  useEffect(() => {
    if (!latitude || !longitude || permission !== 'granted' || nearbyBuses.length === 0) return;

    const nearbyThreshold = 1; // 1 km threshold for notifications
    const newNotifiedBuses = new Set(notifiedBuses);
    let hasChanges = false;

    nearbyBuses.forEach((bus) => {
      if (bus.distance <= nearbyThreshold && !notifiedBuses.has(bus.id)) {
        sendNotification(
          `🚌 Bus ${bus.bus_number} Nearby!`,
          {
            body: `Bus is ${bus.distance.toFixed(1)}km away on route ${bus.route?.route_name || 'Unknown'}`,
            tag: bus.id,
          }
        );
        newNotifiedBuses.add(bus.id);
        hasChanges = true;
      }
      
      // Remove buses that are no longer nearby
      if (bus.distance > nearbyThreshold && notifiedBuses.has(bus.id)) {
        newNotifiedBuses.delete(bus.id);
        hasChanges = true;
      }
    });

    if (hasChanges) {
      setNotifiedBuses(newNotifiedBuses);
    }
  }, [nearbyBuses, latitude, longitude, permission, notifiedBuses, sendNotification]);

  // Calculate distance between two coordinates (Haversine formula)
  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371; // Earth's radius in km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  };

  useEffect(() => {
    if (latitude && longitude && buses.length > 0) {
      // Find buses within 5km radius and sort by distance
      const busesWithDistance = buses
        .map(bus => ({
          ...bus,
          distance: calculateDistance(
            latitude,
            longitude,
            bus.current_latitude,
            bus.current_longitude
          )
        }))
        .filter(bus => bus.distance <= 5)
        .sort((a, b) => a.distance - b.distance);
      
      setNearbyBuses(busesWithDistance);
    }
  }, [latitude, longitude, buses]);

  const fetchBuses = async () => {
    try {
      const { data, error } = await supabase
        .from('buses')
        .select(`
          *,
          route:bus_routes(*)
        `)
        .eq('status', 'active');

      if (error) throw error;
      setBuses(data || []);
    } catch (error) {
      console.error('Error fetching buses:', error);
    }
  };

  const subscribeToBuses = () => {
    const channel = supabase
      .channel('buses-realtime')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'buses',
        },
        (payload) => {
          console.log('🚌 Bus position updated:', payload.new);
          setLastUpdate(new Date());
          
          // Show subtle notification for updates
          const bus = payload.new as any;
          toast.success(`Bus ${bus.bus_number} position updated`, {
            duration: 2000,
            description: 'Live GPS tracking active',
          });
          
          // Update individual bus position for smoother updates
          setBuses((prevBuses) => 
            prevBuses.map((bus) => 
              bus.id === payload.new.id 
                ? { ...bus, ...payload.new }
                : bus
            )
          );
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'buses',
        },
        (payload) => {
          console.log('New bus added:', payload);
          setLastUpdate(new Date());
          setBuses((prevBuses) => [...prevBuses, payload.new as any]);
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'DELETE',
          schema: 'public',
          table: 'buses',
        },
        (payload) => {
          console.log('Bus removed:', payload);
          setLastUpdate(new Date());
          setBuses((prevBuses) => 
            prevBuses.filter((bus) => bus.id !== payload.old.id)
          );
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  };

  return (
    <div className="flex flex-col min-h-screen bg-background pb-20">
      {/* Header with gradient */}
      <header className="bg-gradient-primary text-white px-4 pt-6 pb-8 rounded-b-3xl shadow-float">
        <div className="max-w-7xl mx-auto space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold">Hello, Traveler! 👋</h1>
              <p className="text-sm text-white/80 mt-1">Track your bus in real-time</p>
            </div>
            <div className="flex gap-2">
              <NotificationBell />
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigate("/profile")}
                className="bg-white/20 hover:bg-white/30 text-white rounded-full"
              >
                <User className="w-5 h-5" />
              </Button>
            </div>
          </div>

          {/* Search Bar */}
          <div 
            className="relative cursor-pointer"
            onClick={() => navigate("/search")}
          >
            <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <div className="pl-12 pr-4 h-14 bg-white border-0 shadow-card rounded-2xl flex items-center text-muted-foreground">
              Where do you want to go?
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 px-4 -mt-4">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Quick Actions */}
          <Card className="p-4 shadow-card rounded-2xl bg-gradient-card">
            <div className="grid grid-cols-3 gap-3">
              <Button
                variant="ghost"
                onClick={() => navigate("/search")}
                className="flex flex-col items-center gap-2 h-auto py-4 rounded-xl bg-primary/10 hover:bg-primary/20 text-primary"
              >
                <MapPin className="w-6 h-6" />
                <span className="text-xs font-medium">Nearby</span>
              </Button>
              <Button
                variant="ghost"
                onClick={() => navigate("/schedule")}
                className="flex flex-col items-center gap-2 h-auto py-4 rounded-xl bg-chalo-yellow/10 hover:bg-chalo-yellow/20 text-chalo-yellow"
              >
                <Clock className="w-6 h-6" />
                <span className="text-xs font-medium">Schedule</span>
              </Button>
              <Button
                variant="ghost"
                onClick={() => navigate("/track")}
                className="flex flex-col items-center gap-2 h-auto py-4 rounded-xl bg-chalo-orange/10 hover:bg-chalo-orange/20 text-chalo-orange"
              >
                <TrendingUp className="w-6 h-6" />
                <span className="text-xs font-medium">Live</span>
              </Button>
            </div>
          </Card>

          {/* Real-time Map View */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-lg font-bold text-foreground">Live Bus Tracking</h2>
              <div className="flex items-center gap-2">
                {!locationLoading && latitude && longitude && (
                  <Badge className="bg-chalo-green text-white text-xs flex items-center gap-1">
                    <Navigation className="w-3 h-3" />
                    Location Active
                  </Badge>
                )}
                <Badge variant="outline" className="text-xs flex items-center gap-1">
                  <div className="w-2 h-2 bg-chalo-green rounded-full animate-pulse"></div>
                  Live • {lastUpdate.toLocaleTimeString()}
                </Badge>
              </div>
            </div>
            <Card className="shadow-card rounded-2xl overflow-hidden">
              <div className="h-[400px] relative">
                <MapComponent
                  buses={buses.map(bus => ({
                    id: bus.id,
                    latitude: bus.current_latitude,
                    longitude: bus.current_longitude,
                    busNumber: bus.bus_number
                  }))}
                  userLocation={latitude && longitude ? { latitude, longitude } : null}
                  className="w-full h-full"
                />
              </div>
            </Card>
          </div>

          {/* Live Buses Section */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-lg font-bold text-foreground">Live Buses Near You</h2>
              <Button 
                variant="ghost" 
                size="sm" 
                className="text-primary text-sm font-medium"
                onClick={() => navigate("/search")}
              >
                View All
              </Button>
            </div>

            <div className="space-y-3">
              {nearbyBuses.length > 0 ? (
                nearbyBuses.slice(0, 3).map((bus) => (
                  <Card
                    key={bus.id}
                    className="p-4 shadow-card rounded-2xl hover:shadow-float transition-all cursor-pointer"
                    onClick={() => navigate(`/track/${bus.route?.route_number || bus.id}`)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="bg-primary text-white w-12 h-12 rounded-xl flex items-center justify-center font-bold text-lg">
                          {bus.bus_number}
                        </div>
                        <div>
                          <h3 className="font-semibold text-foreground">
                            {bus.route?.route_name || 'Unknown Route'}
                          </h3>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                            <Navigation className="w-4 h-4" />
                            <span>{bus.distance.toFixed(1)} km away</span>
                            <LiveIndicator lastUpdated={bus.last_updated} />
                          </div>
                        </div>
                      </div>
                      <Button
                        size="sm"
                        className="bg-primary hover:bg-primary/90 text-white rounded-xl shadow-soft"
                      >
                        Track
                      </Button>
                    </div>
                  </Card>
                ))
              ) : buses.length > 0 ? (
                buses.slice(0, 3).map((bus) => (
                  <Card
                    key={bus.id}
                    className="p-4 shadow-card rounded-2xl hover:shadow-float transition-all cursor-pointer"
                    onClick={() => navigate(`/track/${bus.route?.route_number || bus.id}`)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="bg-primary text-white w-12 h-12 rounded-xl flex items-center justify-center font-bold text-lg">
                          {bus.bus_number}
                        </div>
                        <div>
                          <h3 className="font-semibold text-foreground">
                            {bus.route?.route_name || 'Unknown Route'}
                          </h3>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                            <Bus className="w-4 h-4" />
                            <span>{bus.status}</span>
                            <Badge className="bg-chalo-green text-white text-xs">
                              {bus.current_occupancy}/{bus.capacity}
                            </Badge>
                          </div>
                        </div>
                      </div>
                      <Button
                        size="sm"
                        className="bg-primary hover:bg-primary/90 text-white rounded-xl shadow-soft"
                      >
                        Track
                      </Button>
                    </div>
                  </Card>
                ))
              ) : (
                <Card className="p-8 shadow-card rounded-2xl text-center">
                  <Bus className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
                  <p className="text-muted-foreground">No active buses nearby</p>
                </Card>
              )}
            </div>
          </div>

          {/* Recent Trips */}
          <div>
            <h2 className="text-lg font-bold text-foreground mb-3">Recent Trips</h2>
            <Card className="p-4 shadow-card rounded-2xl">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                  <MapPin className="w-5 h-5 text-primary" />
                </div>
                <div className="flex-1">
                  <p className="font-medium text-foreground">City Center to University</p>
                  <p className="text-sm text-muted-foreground">Route 101 • Yesterday</p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </main>

      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  );
};

export default Home;
