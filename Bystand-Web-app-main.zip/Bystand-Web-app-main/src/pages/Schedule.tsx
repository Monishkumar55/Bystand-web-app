import { useParams, useNavigate } from "react-router-dom";
import { ArrowLeft, MapPin, Clock, Calendar, Bus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import BottomNav from "@/components/BottomNav";
import { useState } from "react";

const Schedule = () => {
  const { routeId } = useParams();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("search");

  const routeData = {
    number: routeId || "101",
    name:
      routeId === "101"
        ? "Downtown Express"
        : routeId === "25"
        ? "Central Station"
        : routeId === "47"
        ? "University Loop"
        : "Airport Shuttle",
    frequency: "Every 10 minutes",
    firstBus: "5:30 AM",
    lastBus: "11:30 PM",
    stops: [
      { name: "Terminal Station", time: "5:30 AM", duration: "Start" },
      { name: "Central Plaza", time: "5:35 AM", duration: "5 min" },
      { name: "City Hall", time: "5:42 AM", duration: "7 min" },
      { name: "University Campus", time: "5:50 AM", duration: "8 min" },
      { name: "Shopping District", time: "5:58 AM", duration: "8 min" },
      { name: "Hospital Junction", time: "6:05 AM", duration: "7 min" },
      { name: "Airport Terminal", time: "6:15 AM", duration: "10 min" },
    ],
  };

  return (
    <div className="flex flex-col min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-gradient-primary text-white p-4 rounded-b-3xl shadow-float">
        <div className="flex items-center gap-3 mb-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate(-1)}
            className="text-white hover:bg-white/20 rounded-full"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <span className="text-2xl font-bold">Route {routeData.number}</span>
            </div>
            <p className="text-sm text-white/80">{routeData.name}</p>
          </div>
          <Button
            size="sm"
            className="bg-white/20 hover:bg-white/30 text-white rounded-xl"
            onClick={() => navigate(`/track/${routeId}`)}
          >
            <Bus className="w-4 h-4 mr-2" />
            Live Track
          </Button>
        </div>

        {/* Route Info */}
        <div className="grid grid-cols-3 gap-3">
          <Card className="bg-white/10 backdrop-blur-sm border-white/20 p-3 rounded-xl">
            <Clock className="w-5 h-5 text-white/80 mb-1" />
            <p className="text-xs text-white/80">Frequency</p>
            <p className="font-semibold text-white text-sm">{routeData.frequency}</p>
          </Card>
          <Card className="bg-white/10 backdrop-blur-sm border-white/20 p-3 rounded-xl">
            <Calendar className="w-5 h-5 text-white/80 mb-1" />
            <p className="text-xs text-white/80">First Bus</p>
            <p className="font-semibold text-white text-sm">{routeData.firstBus}</p>
          </Card>
          <Card className="bg-white/10 backdrop-blur-sm border-white/20 p-3 rounded-xl">
            <Calendar className="w-5 h-5 text-white/80 mb-1" />
            <p className="text-xs text-white/80">Last Bus</p>
            <p className="font-semibold text-white text-sm">{routeData.lastBus}</p>
          </Card>
        </div>
      </div>

      {/* Stops Timeline */}
      <main className="flex-1 px-4 py-6">
        <h2 className="text-lg font-bold text-foreground mb-4">Route Timeline</h2>

        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-border" />

          {/* Stops */}
          <div className="space-y-4">
            {routeData.stops.map((stop, index) => (
              <div key={index} className="relative flex gap-4">
                {/* Timeline dot */}
                <div
                  className={`relative z-10 w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 ${
                    index === 0 || index === routeData.stops.length - 1
                      ? "bg-primary"
                      : "bg-card border-2 border-border"
                  }`}
                >
                  <MapPin
                    className={`w-5 h-5 ${
                      index === 0 || index === routeData.stops.length - 1
                        ? "text-white"
                        : "text-primary"
                    }`}
                  />
                </div>

                {/* Stop Info */}
                <Card className="flex-1 p-4 shadow-card rounded-2xl">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-semibold text-foreground">{stop.name}</h3>
                      <p className="text-sm text-muted-foreground mt-1">{stop.time}</p>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {stop.duration}
                    </Badge>
                  </div>
                </Card>
              </div>
            ))}
          </div>
        </div>
      </main>

      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  );
};

export default Schedule;
