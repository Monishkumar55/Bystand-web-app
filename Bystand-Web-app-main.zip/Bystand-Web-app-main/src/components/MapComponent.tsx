import { useEffect, useRef, useState } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

interface MapComponentProps {
  buses?: Array<{
    id: string;
    latitude: number;
    longitude: number;
    busNumber: string;
  }>;
  stops?: Array<{
    id: string;
    latitude: number;
    longitude: number;
    name: string;
  }>;
  center?: [number, number];
  zoom?: number;
  className?: string;
  userLocation?: { latitude: number; longitude: number } | null;
  showUserLocation?: boolean;
}

const MapComponent = ({ 
  buses = [], 
  stops = [], 
  center = [77.5946, 12.9716], // Bangalore
  zoom = 12,
  className = "w-full h-full",
  userLocation = null,
  showUserLocation = true
}: MapComponentProps) => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const markersRef = useRef<{ [key: string]: mapboxgl.Marker }>({});
  const userMarkerRef = useRef<mapboxgl.Marker | null>(null);
  const [token, setToken] = useState(localStorage.getItem('mapbox_token') || '');
  const [inputToken, setInputToken] = useState('');
  const [showTokenInput, setShowTokenInput] = useState(!localStorage.getItem('mapbox_token'));

  const handleSaveToken = () => {
    if (inputToken.trim()) {
      localStorage.setItem('mapbox_token', inputToken.trim());
      setToken(inputToken.trim());
      setShowTokenInput(false);
    }
  };

  useEffect(() => {
    if (!mapContainer.current || map.current || !token) return;

    // Initialize map
    mapboxgl.accessToken = token;
    
    const initialCenter = userLocation 
      ? [userLocation.longitude, userLocation.latitude] as [number, number]
      : center;
    
    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: 'mapbox://styles/mapbox/streets-v12',
      center: initialCenter,
      zoom: userLocation ? 14 : zoom,
    });

    // Add navigation controls
    map.current.addControl(
      new mapboxgl.NavigationControl({
        visualizePitch: true,
      }),
      'top-right'
    );

    return () => {
      map.current?.remove();
      map.current = null;
    };
  }, [token]);

  // Update user location marker
  useEffect(() => {
    if (!map.current || !showUserLocation) return;

    // Remove old user marker
    if (userMarkerRef.current) {
      userMarkerRef.current.remove();
      userMarkerRef.current = null;
    }

    // Add user location marker
    if (userLocation) {
      const el = document.createElement('div');
      el.innerHTML = `
        <div class="relative">
          <div class="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center shadow-lg border-4 border-white animate-pulse">
            <div class="w-3 h-3 bg-white rounded-full"></div>
          </div>
          <div class="absolute inset-0 w-10 h-10 bg-blue-500/30 rounded-full animate-ping"></div>
        </div>
      `;

      userMarkerRef.current = new mapboxgl.Marker(el)
        .setLngLat([userLocation.longitude, userLocation.latitude])
        .setPopup(
          new mapboxgl.Popup({ offset: 25 })
            .setHTML('<strong>Your Location</strong>')
        )
        .addTo(map.current);

      // Center map on user location
      map.current.flyTo({
        center: [userLocation.longitude, userLocation.latitude],
        zoom: 14,
        duration: 1500
      });
    }
  }, [userLocation, showUserLocation]);

  // Update bus markers with smooth transitions
  useEffect(() => {
    if (!map.current) return;

    // Get current bus IDs
    const currentBusIds = new Set(buses.map(b => b.id));
    const existingBusIds = new Set(Object.keys(markersRef.current).filter(k => !k.startsWith('stop-')));

    // Remove markers for buses that no longer exist
    existingBusIds.forEach(busId => {
      if (!currentBusIds.has(busId)) {
        markersRef.current[busId]?.remove();
        delete markersRef.current[busId];
      }
    });

    // Add or update bus markers
    buses.forEach(bus => {
      if (bus.latitude && bus.longitude) {
        const existingMarker = markersRef.current[bus.id];
        
        if (existingMarker) {
          // Smoothly animate existing marker to new position
          const currentLngLat = existingMarker.getLngLat();
          const newLngLat: [number, number] = [bus.longitude, bus.latitude];
          
          // Only animate if position changed significantly (more than 0.0001 degrees ~ 11m)
          const distance = Math.sqrt(
            Math.pow(currentLngLat.lng - newLngLat[0], 2) + 
            Math.pow(currentLngLat.lat - newLngLat[1], 2)
          );
          
          if (distance > 0.0001) {
            // Animate the marker smoothly
            const duration = 2000; // 2 seconds
            const steps = 60; // 60 frames
            const stepDuration = duration / steps;
            let step = 0;
            
            const animate = () => {
              step++;
              const progress = step / steps;
              const easeProgress = 1 - Math.pow(1 - progress, 3); // Ease out cubic
              
              const lat = currentLngLat.lat + (newLngLat[1] - currentLngLat.lat) * easeProgress;
              const lng = currentLngLat.lng + (newLngLat[0] - currentLngLat.lng) * easeProgress;
              
              existingMarker.setLngLat([lng, lat]);
              
              if (step < steps) {
                setTimeout(animate, stepDuration);
              }
            };
            
            animate();
          }
          
          // Update popup
          existingMarker.setPopup(
            new mapboxgl.Popup({ offset: 25 })
              .setHTML(`<strong>Bus ${bus.busNumber}</strong><br/><small>Live tracking</small>`)
          );
        } else {
          // Create new marker
          const el = document.createElement('div');
          el.className = 'bus-marker';
          el.innerHTML = `
            <div class="w-8 h-8 bg-primary rounded-full flex items-center justify-center shadow-lg border-2 border-white transition-transform hover:scale-110">
              <svg class="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path d="M17 20H3a1 1 0 01-1-1V5a3 3 0 013-3h10a3 3 0 013 3v14a1 1 0 01-1 1zM5 4a1 1 0 00-1 1v13h12V5a1 1 0 00-1-1H5z"/>
                <path d="M7 8h2v2H7V8zm4 0h2v2h-2V8zM7 12h2v2H7v-2zm4 0h2v2h-2v-2z"/>
              </svg>
            </div>
            <div class="absolute top-0 left-0 w-8 h-8 bg-primary/30 rounded-full animate-ping"></div>
          `;

          const marker = new mapboxgl.Marker(el)
            .setLngLat([bus.longitude, bus.latitude])
            .setPopup(
              new mapboxgl.Popup({ offset: 25 })
                .setHTML(`<strong>Bus ${bus.busNumber}</strong><br/><small>Live tracking</small>`)
            )
            .addTo(map.current!);

          markersRef.current[bus.id] = marker;
        }
      }
    });

    // Update stop markers (only if they changed)
    const existingStopIds = new Set(
      Object.keys(markersRef.current)
        .filter(k => k.startsWith('stop-'))
        .map(k => k.replace('stop-', ''))
    );
    const currentStopIds = new Set(stops.map(s => s.id));

    // Only update stops if the set changed
    const stopsChanged = 
      stops.length !== existingStopIds.size ||
      !stops.every(s => existingStopIds.has(s.id));

    if (stopsChanged) {
      // Remove old stop markers
      existingStopIds.forEach(stopId => {
        const key = `stop-${stopId}`;
        markersRef.current[key]?.remove();
        delete markersRef.current[key];
      });

      // Add stop markers
      stops.forEach(stop => {
        if (stop.latitude && stop.longitude) {
          const el = document.createElement('div');
          el.innerHTML = `
            <div class="w-6 h-6 bg-white rounded-full flex items-center justify-center shadow-md border-2 border-border">
              <div class="w-2 h-2 bg-muted-foreground rounded-full"></div>
            </div>
          `;

          const marker = new mapboxgl.Marker(el)
            .setLngLat([stop.longitude, stop.latitude])
            .setPopup(
              new mapboxgl.Popup({ offset: 15 })
                .setHTML(`<p class="text-sm font-medium">${stop.name}</p>`)
            )
            .addTo(map.current!);

          markersRef.current[`stop-${stop.id}`] = marker;
        }
      });
    }
  }, [buses, stops]);

  if (showTokenInput || !token) {
    return (
      <div className={`${className} flex items-center justify-center bg-muted/20`}>
        <div className="max-w-md w-full p-6 space-y-4">
          <div className="text-center space-y-2">
            <h3 className="text-lg font-semibold text-foreground">Mapbox Token Required</h3>
            <p className="text-sm text-muted-foreground">
              Please enter your Mapbox public token to view the map. Get one from{' '}
              <a 
                href="https://account.mapbox.com/access-tokens/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-primary hover:underline"
              >
                mapbox.com
              </a>
            </p>
          </div>
          <div className="space-y-2">
            <Input
              type="text"
              placeholder="pk.eyJ1..."
              value={inputToken}
              onChange={(e) => setInputToken(e.target.value)}
              className="w-full"
            />
            <Button 
              onClick={handleSaveToken}
              className="w-full bg-primary hover:bg-primary/90"
              disabled={!inputToken.trim()}
            >
              Save Token
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return <div ref={mapContainer} className={className} />;
};

export default MapComponent;