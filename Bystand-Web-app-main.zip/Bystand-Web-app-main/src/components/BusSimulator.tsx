import { useState, useEffect } from "react";
import { Play, Pause, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface BusSimulatorProps {
  buses: any[];
}

const BusSimulator = ({ buses }: BusSimulatorProps) => {
  const [isSimulating, setIsSimulating] = useState(false);
  const [simulatingBuses, setSimulatingBuses] = useState<Set<string>>(new Set());

  useEffect(() => {
    if (!isSimulating) return;

    const interval = setInterval(() => {
      simulateBusMovement();
    }, 3000); // Update every 3 seconds

    return () => clearInterval(interval);
  }, [isSimulating, buses]);

  const simulateBusMovement = async () => {
    for (const bus of buses.filter(b => simulatingBuses.has(b.id))) {
      try {
        // Simulate small GPS movements (approximately 100-500 meters)
        const latOffset = (Math.random() - 0.5) * 0.005; // ~0-550m
        const lonOffset = (Math.random() - 0.5) * 0.005;
        
        const newLat = parseFloat(bus.current_latitude) + latOffset;
        const newLon = parseFloat(bus.current_longitude) + lonOffset;

        // Update occupancy randomly
        const occupancyChange = Math.floor(Math.random() * 5) - 2; // -2 to +2
        const newOccupancy = Math.max(
          0, 
          Math.min(
            bus.capacity, 
            bus.current_occupancy + occupancyChange
          )
        );

        const { error } = await supabase
          .from('buses')
          .update({
            current_latitude: newLat,
            current_longitude: newLon,
            current_occupancy: newOccupancy,
            last_updated: new Date().toISOString(),
          })
          .eq('id', bus.id);

        if (error) throw error;
      } catch (error) {
        console.error('Error simulating bus movement:', error);
      }
    }
  };

  const toggleSimulation = () => {
    if (!isSimulating && simulatingBuses.size === 0) {
      // Start simulation for all buses
      setSimulatingBuses(new Set(buses.map(b => b.id)));
      toast.success('GPS simulation started for all buses');
    }
    setIsSimulating(!isSimulating);
  };

  const toggleBusSimulation = (busId: string) => {
    setSimulatingBuses(prev => {
      const next = new Set(prev);
      if (next.has(busId)) {
        next.delete(busId);
        toast.info('Stopped simulating bus');
      } else {
        next.add(busId);
        toast.success('Started simulating bus');
      }
      return next;
    });
  };

  const resetSimulation = () => {
    setIsSimulating(false);
    setSimulatingBuses(new Set());
    toast.info('Simulation reset');
  };

  return (
    <Card className="p-4 shadow-card rounded-2xl">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-semibold text-foreground">GPS Simulator</h3>
            <p className="text-xs text-muted-foreground">
              Simulate real-time bus location updates
            </p>
          </div>
          <Badge className={isSimulating ? "bg-chalo-green" : "bg-muted"}>
            {isSimulating ? 'Active' : 'Paused'}
          </Badge>
        </div>

        <div className="flex gap-2">
          <Button
            onClick={toggleSimulation}
            className="flex-1 bg-primary hover:bg-primary/90 text-white rounded-xl"
          >
            {isSimulating ? (
              <>
                <Pause className="w-4 h-4 mr-2" />
                Pause
              </>
            ) : (
              <>
                <Play className="w-4 h-4 mr-2" />
                Start
              </>
            )}
          </Button>
          <Button
            onClick={resetSimulation}
            variant="outline"
            className="rounded-xl"
          >
            <RotateCcw className="w-4 h-4" />
          </Button>
        </div>

        <div className="space-y-2">
          <p className="text-xs text-muted-foreground">
            Simulating {simulatingBuses.size} of {buses.length} buses
          </p>
          <div className="space-y-1 max-h-40 overflow-y-auto">
            {buses.map((bus) => (
              <div
                key={bus.id}
                className="flex items-center justify-between p-2 rounded-lg hover:bg-muted/50"
              >
                <span className="text-sm font-medium">
                  Bus {bus.bus_number}
                </span>
                <Button
                  size="sm"
                  variant={simulatingBuses.has(bus.id) ? "default" : "outline"}
                  onClick={() => toggleBusSimulation(bus.id)}
                  className="h-7 text-xs rounded-lg"
                >
                  {simulatingBuses.has(bus.id) ? 'ON' : 'OFF'}
                </Button>
              </div>
            ))}
          </div>
        </div>

        <div className="text-xs text-muted-foreground">
          <p>• Updates every 3 seconds</p>
          <p>• Simulates ~100-500m movements</p>
          <p>• Random occupancy changes</p>
        </div>
      </div>
    </Card>
  );
};

export default BusSimulator;
