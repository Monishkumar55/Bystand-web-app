import { Badge } from "@/components/ui/badge";

interface LiveIndicatorProps {
  lastUpdated?: string;
  className?: string;
}

const LiveIndicator = ({ lastUpdated, className = "" }: LiveIndicatorProps) => {
  const getTimeSince = (dateString?: string) => {
    if (!dateString) return "unknown";
    
    const now = new Date().getTime();
    const updated = new Date(dateString).getTime();
    const diffSeconds = Math.floor((now - updated) / 1000);
    
    if (diffSeconds < 10) return "just now";
    if (diffSeconds < 60) return `${diffSeconds}s ago`;
    if (diffSeconds < 3600) return `${Math.floor(diffSeconds / 60)}m ago`;
    return `${Math.floor(diffSeconds / 3600)}h ago`;
  };

  const timeSince = getTimeSince(lastUpdated);
  const isRecent = lastUpdated && new Date().getTime() - new Date(lastUpdated).getTime() < 10000;

  return (
    <Badge 
      variant={isRecent ? "default" : "secondary"}
      className={`text-xs flex items-center gap-1 ${
        isRecent ? "bg-chalo-green text-white" : ""
      } ${className}`}
    >
      <div className={`w-1.5 h-1.5 rounded-full ${
        isRecent ? "bg-white animate-pulse" : "bg-muted-foreground"
      }`}></div>
      {isRecent ? "LIVE" : timeSince}
    </Badge>
  );
};

export default LiveIndicator;
