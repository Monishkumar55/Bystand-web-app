import { Home, Search, Ticket, User, Shield, Bus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { useAdmin } from "@/hooks/useAdmin";
import { useDriver } from "@/hooks/useDriver";

interface BottomNavProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const BottomNav = ({ activeTab, onTabChange }: BottomNavProps) => {
  const navigate = useNavigate();
  const { isAdmin } = useAdmin();
  const { isDriver } = useDriver();

  const baseTabs = [
    { id: "home", icon: Home, label: "Home", path: "/home" },
    { id: "search", icon: Search, label: "Search", path: "/search" },
    { id: "tickets", icon: Ticket, label: "Tickets", path: "/tickets" },
    { id: "profile", icon: User, label: "Profile", path: "/profile" },
  ];

  const adminTab = { id: "admin", icon: Shield, label: "Admin", path: "/admin" };
  const driverTab = { id: "driver", icon: Bus, label: "Driver", path: "/driver" };
  
  let tabs = [...baseTabs];
  if (isAdmin) tabs.push(adminTab);
  if (isDriver) tabs.push(driverTab);

  const handleTabClick = (tab: typeof tabs[0]) => {
    onTabChange(tab.id);
    navigate(tab.path);
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-card border-t border-border shadow-float z-50">
      <div className="flex items-center justify-around px-2 py-3 max-w-7xl mx-auto">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          
          return (
            <Button
              key={tab.id}
              variant="ghost"
              onClick={() => handleTabClick(tab)}
              className={`flex flex-col items-center gap-1 h-auto py-2 px-4 rounded-2xl transition-all ${
                isActive
                  ? "text-primary bg-primary/10"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? "scale-110" : ""} transition-transform`} />
              <span className={`text-xs font-medium ${isActive ? "font-semibold" : ""}`}>
                {tab.label}
              </span>
            </Button>
          );
        })}
      </div>
    </div>
  );
};

export default BottomNav;
